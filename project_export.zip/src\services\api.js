import axios from "axios";

export const API_BASE = "http://127.0.0.1:8080";

const api = axios.create({
  baseURL: API_BASE,
});

// Request interceptor to attach the JWT token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers["Authorization"] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export default api;
