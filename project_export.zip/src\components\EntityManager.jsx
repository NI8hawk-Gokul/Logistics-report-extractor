import React, { useState, useEffect } from "react";
import api from "../services/api";

function EntityManager() {
  const [clients, setClients] = useState([]);
  const [agents, setAgents] = useState([]);
  
  // Client inputs
  const [cName, setCName] = useState("");
  const [cEmail, setCEmail] = useState("");
  const [cPhone, setCPhone] = useState("");
  const [cAddress, setCAddress] = useState("");

  // Agent inputs
  const [aName, setAName] = useState("");
  const [aEmail, setAEmail] = useState("");
  const [aPhone, setAPhone] = useState("");
  const [aBranch, setABranch] = useState("Chennai");

  const fetchData = async () => {
    try {
      const cRes = await api.get("/clients");
      setClients(cRes.data);
      const aRes = await api.get("/agents");
      setAgents(aRes.data);
    } catch (error) {
      console.error("Failed to load entity data", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddClient = async (e) => {
    e.preventDefault();
    if (!cName || !cEmail) return;
    try {
      const response = await api.post("/clients", { name: cName, email: cEmail, phone: cPhone, address: cAddress });
      setClients([...clients, response.data]);
      setCName(""); setCEmail(""); setCPhone(""); setCAddress("");
      alert("Client registered successfully!");
    } catch (error) {
      alert("Failed to add client: " + error.response?.data?.detail || error.message);
    }
  };

  const handleAddAgent = async (e) => {
    e.preventDefault();
    if (!aName || !aEmail) return;
    try {
      const response = await api.post("/agents", { name: aName, email: aEmail, phone: aPhone, branch: aBranch });
      setAgents([...agents, response.data]);
      setAName(""); setAEmail(""); setAPhone("");
      alert("Agent registered successfully!");
    } catch (error) {
      alert("Failed to add agent: " + error.response?.data?.detail || error.message);
    }
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
      {/* Clients Management */}
      <div className="card padding" style={{ background: "white", borderRadius: "12px", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }}>
        <h3>Logistics Clients</h3>
        
        <form onSubmit={handleAddClient} style={{ display: "flex", flexDirection: "column", gap: "8px", marginBottom: "20px", borderBottom: "1px solid #eee", paddingBottom: "15px" }}>
          <h4>Register Client</h4>
          <input type="text" placeholder="Client Name" value={cName} onChange={(e) => setCName(e.target.value)} required style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <input type="email" placeholder="Email Address" value={cEmail} onChange={(e) => setCEmail(e.target.value)} required style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <input type="text" placeholder="Phone Number" value={cPhone} onChange={(e) => setCPhone(e.target.value)} style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <input type="text" placeholder="Billing Address" value={cAddress} onChange={(e) => setCAddress(e.target.value)} style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <button type="submit" style={{ margin: "5px 0" }}>Register Client</button>
        </form>

        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "14px" }}>
          <thead>
            <tr style={{ background: "#f3f4f6" }}>
              <th style={{ padding: "8px", textAlign: "left" }}>Name</th>
              <th style={{ padding: "8px", textAlign: "left" }}>Email</th>
              <th style={{ padding: "8px", textAlign: "left" }}>Phone</th>
            </tr>
          </thead>
          <tbody>
            {clients.map((c) => (
              <tr key={c.id} style={{ borderBottom: "1px solid #eee" }}>
                <td style={{ padding: "8px", fontWeight: "600" }}>{c.name}</td>
                <td style={{ padding: "8px" }}>{c.email}</td>
                <td style={{ padding: "8px" }}>{c.phone || "N/A"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Agents Management */}
      <div className="card padding" style={{ background: "white", borderRadius: "12px", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }}>
        <h3>Operating Agents</h3>
        
        <form onSubmit={handleAddAgent} style={{ display: "flex", flexDirection: "column", gap: "8px", marginBottom: "20px", borderBottom: "1px solid #eee", paddingBottom: "15px" }}>
          <h4>Register Agent</h4>
          <input type="text" placeholder="Agent Name" value={aName} onChange={(e) => setAName(e.target.value)} required style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <input type="email" placeholder="Email Address" value={aEmail} onChange={(e) => setAEmail(e.target.value)} required style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <input type="text" placeholder="Phone Number" value={aPhone} onChange={(e) => setAPhone(e.target.value)} style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <select value={aBranch} onChange={(e) => setABranch(e.target.value)} style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }}>
            <option value="Chennai">Chennai</option>
            <option value="Mumbai">Mumbai</option>
            <option value="Bangalore">Bangalore</option>
          </select>
          <button type="submit" style={{ margin: "5px 0" }}>Register Agent</button>
        </form>

        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "14px" }}>
          <thead>
            <tr style={{ background: "#f3f4f6" }}>
              <th style={{ padding: "8px", textAlign: "left" }}>Name</th>
              <th style={{ padding: "8px", textAlign: "left" }}>Email</th>
              <th style={{ padding: "8px", textAlign: "left" }}>Branch</th>
            </tr>
          </thead>
          <tbody>
            {agents.map((a) => (
              <tr key={a.id} style={{ borderBottom: "1px solid #eee" }}>
                <td style={{ padding: "8px", fontWeight: "600" }}>{a.name}</td>
                <td style={{ padding: "8px" }}>{a.email}</td>
                <td style={{ padding: "8px" }}>{a.branch}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default EntityManager;
