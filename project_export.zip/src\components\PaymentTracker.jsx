import React, { useState, useEffect } from "react";
import api from "../services/api";

function PaymentTracker({ role }) {
  const [payments, setPayments] = useState([]);

  const fetchPayments = async () => {
    try {
      const response = await api.get("/payments");
      setPayments(response.data);
    } catch (error) {
      console.error("Failed to load payments", error);
    }
  };

  useEffect(() => {
    fetchPayments();
  }, []);

  const handleMarkPaid = async (paymentId) => {
    try {
      const response = await api.patch(`/payments/${paymentId}/mark-paid`);
      if (response.data.requires_approval) {
        alert("Verification Required: " + response.data.message);
      } else {
        alert(response.data.message || "Payment marked as paid!");
      }
      fetchPayments();
    } catch (error) {
      alert("Action failed: " + error.response?.data?.detail || error.message);
    }
  };

  return (
    <div className="card padding" style={{ background: "white", borderRadius: "12px", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }}>
      <h3>Logistics Invoice Payments</h3>
      
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "14px", marginTop: "15px" }}>
        <thead>
          <tr style={{ background: "#f3f4f6" }}>
            <th style={{ padding: "10px", textAlign: "left" }}>Invoice No</th>
            <th style={{ padding: "10px", textAlign: "left" }}>Client</th>
            <th style={{ padding: "10px", textAlign: "left" }}>Amount</th>
            <th style={{ padding: "10px", textAlign: "left" }}>Status</th>
            {role !== "Staff" && <th style={{ padding: "10px", textAlign: "center" }}>Actions</th>}
          </tr>
        </thead>
        <tbody>
          {payments.map((p) => (
            <tr key={p.id} style={{ borderBottom: "1px solid #eee" }}>
              <td style={{ padding: "10px", fontWeight: "600" }}>{p.invoiceNo}</td>
              <td style={{ padding: "10px" }}>{p.clientName}</td>
              <td style={{ padding: "10px" }}>₹{p.amount.toLocaleString()}</td>
              <td style={{ padding: "10px" }}>
                <span style={{
                  padding: "4px 8px", borderRadius: "12px", fontSize: "12px", fontWeight: "bold",
                  background: p.status === "Paid" ? "#d1fae5" : "#fee2e2",
                  color: p.status === "Paid" ? "#065f46" : "#991b1b"
                }}>
                  {p.status}
                </span>
              </td>
              {role !== "Staff" && (
                <td style={{ padding: "10px", textAlign: "center" }}>
                  {p.status !== "Paid" && (
                    <button onClick={() => handleMarkPaid(p.id)} style={{ padding: "6px 12px", fontSize: "12px", margin: 0 }}>
                      Mark Paid
                    </button>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default PaymentTracker;
