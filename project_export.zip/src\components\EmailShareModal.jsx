import React, { useState } from "react";
import api from "../services/api";

function EmailShareModal({ isOpen, onClose, filters }) {
  const [toEmail, setToEmail] = useState("");
  const [subject, setSubject] = useState("Logistics Report Extract");
  const [message, setMessage] = useState("Please find the extracted sub-report files attached.");
  const [attachmentType, setAttachmentType] = useState("pdf");
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    if (!toEmail) {
      alert("Please provide receiver email address.");
      return;
    }
    setSending(true);
    try {
      const response = await api.post(`/share-report-email`, {
        toEmail,
        subject,
        message,
        attachmentType,
        filters
      });
      alert(response.data.message || "Email shared successfully!");
      onClose();
    } catch (error) {
      console.error(error);
      alert("Failed to share report by email");
    } finally {
      setSending(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div style={{
      position: "fixed", top: 0, left: 0, width: "100%", height: "100%",
      background: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center",
      alignItems: "center", zIndex: 1000
    }}>
      <div style={{
        background: "white", padding: "24px", borderRadius: "12px",
        width: "450px", boxShadow: "0 4px 20px rgba(0,0,0,0.15)"
      }}>
        <h3 style={{ marginTop: 0, color: "#1e3a8a" }}>Share Report by Email</h3>
        
        <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginTop: "15px" }}>
          <div>
            <label style={{ fontWeight: "bold", fontSize: "14px" }}>Receiver Email</label>
            <input
              type="email"
              placeholder="manager@example.com"
              value={toEmail}
              onChange={(e) => setToEmail(e.target.value)}
              style={{ width: "100%", padding: "8px", borderRadius: "6px", border: "1px solid #ccc", marginTop: "4px" }}
            />
          </div>

          <div>
            <label style={{ fontWeight: "bold", fontSize: "14px" }}>Email Subject</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              style={{ width: "100%", padding: "8px", borderRadius: "6px", border: "1px solid #ccc", marginTop: "4px" }}
            />
          </div>

          <div>
            <label style={{ fontWeight: "bold", fontSize: "14px" }}>Message Body</label>
            <textarea
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              style={{ width: "100%", padding: "8px", borderRadius: "6px", border: "1px solid #ccc", marginTop: "4px" }}
            />
          </div>

          <div>
            <label style={{ fontWeight: "bold", fontSize: "14px" }}>Attachment Format</label>
            <select
              value={attachmentType}
              onChange={(e) => setAttachmentType(e.target.value)}
              style={{ width: "100%", padding: "8px", borderRadius: "6px", border: "1px solid #ccc", marginTop: "4px" }}
            >
              <option value="excel">Excel Spreadsheet (.xlsx)</option>
              <option value="pdf">PDF Report (.pdf)</option>
              <option value="both">Both PDF and Excel</option>
            </select>
          </div>
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", gap: "10px", marginTop: "20px" }}>
          <button onClick={onClose} style={{ background: "#e5e7eb", color: "#374151" }}>Cancel</button>
          <button onClick={handleSend} disabled={sending}>
            {sending ? "Sending Email..." : "Send Email"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default EmailShareModal;
