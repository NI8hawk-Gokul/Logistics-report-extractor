import React, { useState, useEffect } from "react";
import api, { API_BASE } from "./services/api";
import "./App.css";

// Import custom components
import AnalyticsDashboard from "./components/AnalyticsDashboard";
import AISummary from "./components/AISummary";
import EmailShareModal from "./components/EmailShareModal";
import OrgManager from "./components/OrgManager";
import EntityManager from "./components/EntityManager";
import PaymentTracker from "./components/PaymentTracker";
import ApprovalCenter from "./components/ApprovalCenter";
import BackupSettings from "./components/BackupSettings";
import AIChatAssistant from "./components/AIChatAssistant";

const REQUIRED_SYSTEM_FIELDS = [
  "Agent Name", "Client Name", "Job Type", "Status", "Job No", "Billing Amount", "Expense", "Profit", "Date"
];

function App() {
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("dashboard");

  // Report Versioning
  const [versions, setVersions] = useState([]);
  const [selectedReportId, setSelectedReportId] = useState("");

  // Upload & Mapping
  const [file, setFile] = useState(null);
  const [previewData, setPreviewData] = useState(null);
  const [columnMapping, setColumnMapping] = useState({});
  const [rptName, setRptName] = useState("");
  const [rptPeriod, setRptPeriod] = useState("");
  const [rptDesc, setRptDesc] = useState("");

  // Report Data & Filtering
  const [reportData, setReportData] = useState([]);
  const [filters, setFilters] = useState({
    agents: [], clients: [], jobTypes: [], statuses: [], branches: [], departments: []
  });
  const [selectedFilters, setSelectedFilters] = useState({
    agentName: [], clientName: [], jobType: [], status: [], branch: [], department: []
  });
  const [dateRange, setDateRange] = useState({ fromDate: "", toDate: "" });
  const [profitRange, setProfitRange] = useState({ minProfit: "", maxProfit: "" });
  const [billingRange, setBillingRange] = useState({ minBilling: "", maxBilling: "" });
  const [searchText, setSearchText] = useState("");

  // Table Sorting
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "ascending" });

  // Analytics & Logs
  const [analyticsData, setAnalyticsData] = useState(null);
  const [activityLogs, setActivityLogs] = useState([]);

  // Email Sharing Modal
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);

  // Login inputs
  const [emailInput, setEmailInput] = useState("");
  const [passwordInput, setPasswordInput] = useState("");

  // Templates & Schedules
  const [templates, setTemplates] = useState([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState("");
  const [templateNameInput, setTemplateNameInput] = useState("");
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);

  // Fetch logged-in user profile
  const fetchProfile = async () => {
    try {
      const response = await api.get("/me");
      setUser(response.data);
    } catch (error) {
      handleLogout();
    }
  };

  useEffect(() => {
    if (token) {
      localStorage.setItem("token", token);
      fetchProfile();
    } else {
      localStorage.removeItem("token");
      setUser(null);
    }
  }, [token]);

  // Load versions and filters on user authenticate
  useEffect(() => {
    if (user) {
      fetchVersions();
      fetchTemplates();
    }
  }, [user]);

  // Load report data and analytics when selected version changes
  useEffect(() => {
    if (selectedReportId) {
      fetchReportData();
      fetchFilters();
      fetchAnalytics();
    }
  }, [selectedReportId]);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/login", { email: emailInput, password: passwordInput });
      setToken(response.data.access_token);
      setEmailInput("");
      setPasswordInput("");
    } catch (error) {
      alert("Authentication failed: " + (error.response?.data?.detail || error.message));
    }
  };

  const handleLogout = () => {
    setToken("");
    localStorage.removeItem("token");
    setUser(null);
    setActiveTab("dashboard");
    setReportData([]);
    setVersions([]);
    setSelectedReportId("");
  };

  const fetchVersions = async () => {
    try {
      const response = await api.get("/report-versions");
      setVersions(response.data);
      const active = response.data.find(v => v.isActive);
      if (active) {
        setSelectedReportId(active.reportId);
      } else if (response.data.length > 0) {
        setSelectedReportId(response.data[0].reportId);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const fetchReportData = async () => {
    try {
      const response = await api.post("/filter-report", {
        reportId: selectedReportId,
        ...selectedFilters,
        dateRange,
        profitRange,
        billingRange,
        searchText
      });
      setReportData(response.data.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchFilters = async () => {
    try {
      const response = await api.get("/filters", { params: { reportId: selectedReportId } });
      setFilters(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchAnalytics = async () => {
    try {
      const response = await api.get("/analytics", { params: { reportId: selectedReportId } });
      setAnalyticsData(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchTemplates = async () => {
    try {
      const response = await api.get("/templates");
      setTemplates(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchActivityLogs = async () => {
    try {
      const response = await api.get("/activity-logs");
      setActivityLogs(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  // Upload Preview Flow
  const handleUploadFile = async (e) => {
    e.preventDefault();
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);
    try {
      const response = await api.post("/upload-preview", formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      setPreviewData(response.data);
      // Setup initial column mapping
      const initialMap = {};
      REQUIRED_SYSTEM_FIELDS.forEach(field => {
        // Simple fuzzy match for mappings
        const match = response.data.uploadedColumns.find(col => 
          col.toLowerCase().replace(/\s/g, "") === field.toLowerCase().replace(/\s/g, "")
        );
        initialMap[field] = match || "";
      });
      setColumnMapping(initialMap);
      setRptName(response.data.filename.split(".")[0]);
      setRptPeriod(new Date().toLocaleString("en-US", { month: "long", year: "numeric" }));
    } catch (error) {
      alert("Failed to extract preview: " + (error.response?.data?.detail || error.message));
    }
  };

  const handleConfirmMapping = async () => {
    if (!previewData) return;
    // Format mapping payload in reverse (RawHeader -> SystemField) for backend
    const rawToSysMapping = {};
    Object.keys(columnMapping).forEach(sysField => {
      const rawCol = columnMapping[sysField];
      if (rawCol) {
        rawToSysMapping[rawCol] = sysField;
      }
    });

    try {
      const response = await api.post("/confirm-column-mapping", {
        tempId: previewData.tempId,
        mapping: rawToSysMapping,
        reportName: rptName,
        period: rptPeriod,
        description: rptDesc
      });
      alert(response.data.message || "Report mapped and uploaded successfully!");
      setPreviewData(null);
      setFile(null);
      fetchVersions();
      setActiveTab("dashboard");
    } catch (error) {
      alert("Mapping failed: " + (error.response?.data?.detail || error.message));
    }
  };

  // Checkbox handlers
  const handleCheckboxChange = (filterType, value) => {
    setSelectedFilters((prev) => {
      const currentValues = prev[filterType];
      const newValues = currentValues.includes(value)
        ? currentValues.filter((item) => item !== value)
        : [...currentValues, value];
      return { ...prev, [filterType]: newValues };
    });
  };

  const handleResetFilters = () => {
    setSelectedFilters({
      agentName: [], clientName: [], jobType: [], status: [], branch: [], department: []
    });
    setDateRange({ fromDate: "", toDate: "" });
    setProfitRange({ minProfit: "", maxProfit: "" });
    setBillingRange({ minBilling: "", maxBilling: "" });
    setSearchText("");
    setSelectedTemplateId("");
  };

  // Download Handlers
  const handleDownloadExcel = async () => {
    try {
      const response = await api.post("/download-excel", {
        reportId: selectedReportId,
        ...selectedFilters,
        dateRange,
        profitRange,
        billingRange,
        searchText
      }, { responseType: "blob" });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `sub_report_${selectedReportId}.xlsx`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      alert("Excel download failed");
    }
  };

  const handleDownloadPDF = async () => {
    try {
      const response = await api.post("/download-pdf", {
        reportId: selectedReportId,
        ...selectedFilters,
        dateRange,
        profitRange,
        billingRange,
        searchText
      }, { responseType: "blob" });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `sub_report_${selectedReportId}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      alert("PDF download failed");
    }
  };

  // Templates
  const handleSaveTemplate = async () => {
    if (!templateNameInput) return;
    try {
      await api.post("/templates", {
        templateName: templateNameInput,
        filters: {
          selectedFilters, dateRange, profitRange, billingRange, searchText
        }
      });
      alert("Template saved successfully!");
      setTemplateNameInput("");
      setIsTemplateModalOpen(false);
      fetchTemplates();
    } catch (error) {
      alert("Failed to save template");
    }
  };

  const handleApplyTemplate = (templateId) => {
    setSelectedTemplateId(templateId);
    const tmpl = templates.find(t => t.id === templateId);
    if (tmpl && tmpl.filters) {
      const f = tmpl.filters;
      setSelectedFilters(f.selectedFilters || { agentName: [], clientName: [], jobType: [], status: [], branch: [], department: [] });
      setDateRange(f.dateRange || { fromDate: "", toDate: "" });
      setProfitRange(f.profitRange || { minProfit: "", maxProfit: "" });
      setBillingRange(f.billingRange || { minBilling: "", maxBilling: "" });
      setSearchText(f.searchText || "");
    }
  };

  // Sorting Table Logic
  const handleSort = (key) => {
    let direction = "ascending";
    if (sortConfig.key === key && sortConfig.direction === "ascending") {
      direction = "descending";
    }
    setSortConfig({ key, direction });
  };

  const sortedData = React.useMemo(() => {
    let sortableItems = [...reportData];
    if (sortConfig.key !== null) {
      sortableItems.sort((a, b) => {
        let valA = a[sortConfig.key];
        let valB = b[sortConfig.key];

        // Numeric fields checks
        if (["billingAmount", "expense", "profit"].includes(sortConfig.key)) {
          valA = Number(valA) || 0;
          valB = Number(valB) || 0;
        }

        if (valA < valB) {
          return sortConfig.direction === "ascending" ? -1 : 1;
        }
        if (valA > valB) {
          return sortConfig.direction === "ascending" ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [reportData, sortConfig]);

  // Tab change wrapper
  const handleTabChange = (tab) => {
    setActiveTab(tab);
    if (tab === "logs") {
      fetchActivityLogs();
    }
  };

  // Summary Metrics calculations
  const totalBilling = reportData.reduce((acc, curr) => acc + (curr.billingAmount || 0), 0);
  const totalExpense = reportData.reduce((acc, curr) => acc + (curr.expense || 0), 0);
  const totalProfit = reportData.reduce((acc, curr) => acc + (curr.profit || 0), 0);
  const completedJobs = reportData.filter(r => r.status?.toLowerCase() === "completed").length;
  const pendingJobs = reportData.filter(r => r.status?.toLowerCase() === "pending").length;

  if (!user) {
    return (
      <div className="login-container">
        <div className="login-card">
          <h2>Smart Logistics Secure Access</h2>
          <p>Please enter your credentials to access the analytics portal.</p>
          <form onSubmit={handleLogin}>
            <div style={{ textAlign: "left", marginBottom: "16px" }}>
              <label>Email Address</label>
              <input
                type="email"
                placeholder="email@logistics.com"
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                required
              />
            </div>
            <div style={{ textAlign: "left", marginBottom: "20px" }}>
              <label>Password</label>
              <input
                type="password"
                placeholder="••••••••"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                required
              />
            </div>
            <button type="submit">Authenticate</button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="portal-container">
      {/* Header bar */}
      <header className="portal-header">
        <div className="logo-section">
          <h1>Smart Logistics Report Extractor</h1>
        </div>
        <div className="user-profile">
          <span>{user.name} ({user.role})</span>
          <button onClick={handleLogout} className="logout-btn">Logout</button>
        </div>
      </header>

      {/* Navigation Sub-menu */}
      <nav className="portal-nav">
        <button className={activeTab === "dashboard" ? "active" : ""} onClick={() => handleTabChange("dashboard")}>Dashboard</button>
        {user.role === "Admin" && (
          <button className={activeTab === "upload" ? "active" : ""} onClick={() => handleTabChange("upload")}>Upload Report</button>
        )}
        <button className={activeTab === "org" ? "active" : ""} onClick={() => handleTabChange("org")}>Organization Manager</button>
        <button className={activeTab === "entities" ? "active" : ""} onClick={() => handleTabChange("entities")}>Clients & Agents</button>
        <button className={activeTab === "payments" ? "active" : ""} onClick={() => handleTabChange("payments")}>Payments</button>
        {user.role === "Admin" && (
          <>
            <button className={activeTab === "approvals" ? "active" : ""} onClick={() => handleTabChange("approvals")}>Authorization Queue</button>
            <button className={activeTab === "backups" ? "active" : ""} onClick={() => handleTabChange("backups")}>Backups</button>
            <button className={activeTab === "logs" ? "active" : ""} onClick={() => handleTabChange("logs")}>Activity Logs</button>
          </>
        )}
      </nav>

      {/* Version Selector (Top of Dashboard / Reports) */}
      {(activeTab === "dashboard") && (
        <div className="version-selector-bar card">
          <label>Report Archive Version:</label>
          <select value={selectedReportId} onChange={(e) => setSelectedReportId(e.target.value)}>
            {versions.map(v => (
              <option key={v.reportId} value={v.reportId}>{v.reportName} - {v.period} ({v.totalRecords} records)</option>
            ))}
          </select>

          <label style={{ marginLeft: "16px" }}>Load Saved Template:</label>
          <select value={selectedTemplateId} onChange={(e) => handleApplyTemplate(e.target.value)}>
            <option value="">-- Choose Template --</option>
            {templates.map(t => (
              <option key={t.id} value={t.id}>{t.templateName}</option>
            ))}
          </select>
        </div>
      )}

      {/* Content tabs */}
      <main className="portal-content">
        {activeTab === "dashboard" && (
          <div>
            {/* Summary cards */}
            <div className="summary-cards">
              <div className="summary-card total-jobs card">
                <div className="summary-card-content">
                  <h3>Total Jobs</h3>
                  <p>{reportData.length}</p>
                </div>
                <div className="summary-card-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
                </div>
              </div>
              <div className="summary-card completed-jobs card">
                <div className="summary-card-content">
                  <h3>Completed Jobs</h3>
                  <p>{completedJobs}</p>
                </div>
                <div className="summary-card-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                </div>
              </div>
              <div className="summary-card pending-jobs card">
                <div className="summary-card-content">
                  <h3>Pending Jobs</h3>
                  <p>{pendingJobs}</p>
                </div>
                <div className="summary-card-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                </div>
              </div>
              <div className="summary-card billing-amount card">
                <div className="summary-card-content">
                  <h3>Total Billing</h3>
                  <p>₹{totalBilling.toLocaleString()}</p>
                </div>
                <div className="summary-card-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
                </div>
              </div>
              <div className="summary-card expense-amount card">
                <div className="summary-card-content">
                  <h3>Total Expense</h3>
                  <p>₹{totalExpense.toLocaleString()}</p>
                </div>
                <div className="summary-card-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                </div>
              </div>
              <div className="summary-card profit-amount card">
                <div className="summary-card-content">
                  <h3>Total Profit</h3>
                  <p>₹{totalProfit.toLocaleString()}</p>
                </div>
                <div className="summary-card-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
                </div>
              </div>
            </div>

            {/* Recharts Analytics Dashboard */}
            <AnalyticsDashboard data={analyticsData} role={user.role} />

            {/* AI Business summary component */}
            {user.role !== "Staff" && <AISummary reportId={selectedReportId} />}

            {/* Main sidebar filters and report grid layout */}
            <div className="main-layout">
              {/* Left filter panel */}
              <div className="filter-panel card">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
                  <h3 style={{ margin: 0 }}>Filter Sub-Report</h3>
                  <button onClick={() => setIsTemplateModalOpen(true)} className="btn-secondary" style={{ padding: "6px 12px", fontSize: "12px", margin: 0 }}>Save Filter</button>
                </div>

                <div className="filter-section">
                  <h4>Branch Location</h4>
                  {(filters.branches || []).map(b => (
                    <label key={b}>
                      <input type="checkbox" checked={selectedFilters.branch.includes(b)} onChange={() => handleCheckboxChange("branch", b)} />
                      {b}
                    </label>
                  ))}
                </div>

                <div className="filter-section">
                  <h4>Department</h4>
                  {(filters.departments || []).map(d => (
                    <label key={d}>
                      <input type="checkbox" checked={selectedFilters.department.includes(d)} onChange={() => handleCheckboxChange("department", d)} />
                      {d}
                    </label>
                  ))}
                </div>

                <div className="filter-section">
                  <h4>Agent Name</h4>
                  {(filters.agents || []).map(a => (
                    <label key={a}>
                      <input type="checkbox" checked={selectedFilters.agentName.includes(a)} onChange={() => handleCheckboxChange("agentName", a)} />
                      {a}
                    </label>
                  ))}
                </div>

                <div className="filter-section">
                  <h4>Client Name</h4>
                  {(filters.clients || []).map(c => (
                    <label key={c}>
                      <input type="checkbox" checked={selectedFilters.clientName.includes(c)} onChange={() => handleCheckboxChange("clientName", c)} />
                      {c}
                    </label>
                  ))}
                </div>

                <div className="filter-section">
                  <h4>Job Type</h4>
                  {(filters.jobTypes || []).map(jt => (
                    <label key={jt}>
                      <input type="checkbox" checked={selectedFilters.jobType.includes(jt)} onChange={() => handleCheckboxChange("jobType", jt)} />
                      {jt}
                    </label>
                  ))}
                </div>

                <div className="filter-section">
                  <h4>Status</h4>
                  {(filters.statuses || []).map(st => (
                    <label key={st}>
                      <input type="checkbox" checked={selectedFilters.status.includes(st)} onChange={() => handleCheckboxChange("status", st)} />
                      {st}
                    </label>
                  ))}
                </div>

                {/* Range Sliders/Inputs */}
                <div className="filter-section">
                  <h4>Date Range</h4>
                  <input type="date" value={dateRange.fromDate} onChange={(e) => setDateRange({ ...dateRange, fromDate: e.target.value })} className="date-input" />
                  <input type="date" value={dateRange.toDate} onChange={(e) => setDateRange({ ...dateRange, toDate: e.target.value })} className="date-input" />
                </div>

                {user.role !== "Staff" && (
                  <>
                    <div className="filter-section">
                      <h4>Profit Range</h4>
                      <input type="number" placeholder="Min Profit" value={profitRange.minProfit} onChange={(e) => setProfitRange({ ...profitRange, minProfit: e.target.value })} className="date-input" />
                      <input type="number" placeholder="Max Profit" value={profitRange.maxProfit} onChange={(e) => setProfitRange({ ...profitRange, maxProfit: e.target.value })} className="date-input" />
                    </div>

                    <div className="filter-section">
                      <h4>Billing Range</h4>
                      <input type="number" placeholder="Min Billing" value={billingRange.minBilling} onChange={(e) => setBillingRange({ ...billingRange, minBilling: e.target.value })} className="date-input" />
                      <input type="number" placeholder="Max Billing" value={billingRange.maxBilling} onChange={(e) => setBillingRange({ ...billingRange, maxBilling: e.target.value })} className="date-input" />
                    </div>
                  </>
                )}

                <div style={{ display: "flex", flexDirection: "column", gap: "8px", marginTop: "20px" }}>
                  <button onClick={fetchReportData} style={{ width: "100%" }}>Apply Filters</button>
                  <button onClick={handleResetFilters} className="btn-secondary" style={{ width: "100%" }}>Reset Filters</button>
                  {user.role !== "Staff" && (
                    <>
                      <button onClick={handleDownloadExcel} className="btn-success" style={{ width: "100%" }}>Download Excel</button>
                      <button onClick={handleDownloadPDF} className="btn-danger" style={{ width: "100%" }}>Download PDF</button>
                      <button onClick={() => setIsEmailModalOpen(true)} className="btn-purple" style={{ width: "100%" }}>Share by Email</button>
                    </>
                  )}
                </div>
              </div>

              {/* Right table panel */}
              <div className="table-box card padding">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
                  <h3 style={{ margin: 0 }}>Sub-Report Records</h3>
                  <input
                    type="text"
                    placeholder="Search Job No, Agent, Client..."
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                    style={{ padding: "8px 12px", width: "250px", borderRadius: "6px", border: "1px solid #ccc" }}
                  />
                </div>

                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr>
                      <th onClick={() => handleSort("jobNo")} style={{ cursor: "pointer" }}>Job No {sortConfig.key === "jobNo" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}</th>
                      <th onClick={() => handleSort("agentName")} style={{ cursor: "pointer" }}>Agent {sortConfig.key === "agentName" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}</th>
                      <th onClick={() => handleSort("clientName")} style={{ cursor: "pointer" }}>Client {sortConfig.key === "clientName" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}</th>
                      <th onClick={() => handleSort("jobType")} style={{ cursor: "pointer" }}>Type {sortConfig.key === "jobType" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}</th>
                      <th onClick={() => handleSort("status")} style={{ cursor: "pointer" }}>Status {sortConfig.key === "status" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}</th>
                      <th onClick={() => handleSort("billingAmount")} style={{ cursor: "pointer", textAlign: "right" }}>Billing {sortConfig.key === "billingAmount" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}</th>
                      <th onClick={() => handleSort("expense")} style={{ cursor: "pointer", textAlign: "right" }}>Expense {sortConfig.key === "expense" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}</th>
                      <th onClick={() => handleSort("profit")} style={{ cursor: "pointer", textAlign: "right" }}>Profit {sortConfig.key === "profit" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}</th>
                      <th onClick={() => handleSort("date")} style={{ cursor: "pointer" }}>Date {sortConfig.key === "date" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}</th>
                      <th onClick={() => handleSort("branch")} style={{ cursor: "pointer" }}>Branch {sortConfig.key === "branch" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sortedData.map((row) => (
                      <tr key={row.id}>
                        <td style={{ fontWeight: "600" }}>{row.jobNo}</td>
                        <td>{row.agentName}</td>
                        <td>{row.clientName}</td>
                        <td>{row.jobType}</td>
                        <td>
                          <span className={`badge ${row.status?.toLowerCase() === "completed" ? "badge-success" : "badge-warning"}`}>
                            {row.status}
                          </span>
                        </td>
                        <td style={{ textAlign: "right" }}>₹{(row.billingAmount || 0).toLocaleString()}</td>
                        <td style={{ textAlign: "right" }}>₹{(row.expense || 0).toLocaleString()}</td>
                        <td style={{ textAlign: "right", color: row.profit < 0 ? "red" : "inherit" }}>₹{(row.profit || 0).toLocaleString()}</td>
                        <td>{row.date}</td>
                        <td>{row.branch}</td>
                      </tr>
                    ))}
                    {sortedData.length === 0 && (
                      <tr>
                        <td colSpan={10} style={{ padding: "20px", textAlign: "center", color: "#6b7280" }}>No records match your selected criteria.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "upload" && user.role === "Admin" && (
          <div className="card padding" style={{ background: "white", borderRadius: "12px" }}>
            <h3>Logistics Excel/CSV Spreadsheet Uploader</h3>
            {!previewData ? (
              <form onSubmit={handleUploadFile} style={{ display: "flex", flexDirection: "column", gap: "10px", marginTop: "15px" }}>
                <input type="file" accept=".xlsx,.csv" onChange={(e) => setFile(e.target.files[0])} required />
                <button type="submit" style={{ alignSelf: "flex-start" }}>Load Excel Preview</button>
              </form>
            ) : (
              <div style={{ marginTop: "20px" }}>
                <h4>Setup Dynamic Column Mappings</h4>
                <p>Map the headers in your uploaded spreadsheet to the required logistics system fields:</p>
                
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px", marginBottom: "20px" }}>
                  <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                    {REQUIRED_SYSTEM_FIELDS.map(field => (
                      <div key={field} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <span style={{ fontWeight: "bold" }}>{field}:</span>
                        <select
                          value={columnMapping[field] || ""}
                          onChange={(e) => setColumnMapping({ ...columnMapping, [field]: e.target.value })}
                          style={{ padding: "6px", width: "200px", borderRadius: "4px", border: "1px solid #ccc" }}
                        >
                          <option value="">-- Unmapped --</option>
                          {previewData.uploadedColumns.map(col => (
                            <option key={col} value={col}>{col}</option>
                          ))}
                        </select>
                      </div>
                    ))}
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                    <input type="text" placeholder="Report Archive Name (e.g. May 2026 Invoices)" value={rptName} onChange={(e) => setRptName(e.target.value)} style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
                    <input type="text" placeholder="Period (e.g. May 2026)" value={rptPeriod} onChange={(e) => setRptPeriod(e.target.value)} style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
                    <textarea placeholder="Description notes..." value={rptDesc} onChange={(e) => setRptDesc(e.target.value)} style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
                  </div>
                </div>

                <div style={{ display: "flex", gap: "10px" }}>
                  <button onClick={handleConfirmMapping}>Save & Mapping Import</button>
                  <button onClick={() => setPreviewData(null)} style={{ background: "#9ca3af" }}>Cancel</button>
                </div>

                {/* Preview Table */}
                <h4 style={{ marginTop: "25px" }}>File Preview (First 10 Rows)</h4>
                <div style={{ overflowX: "auto" }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "12px" }}>
                    <thead>
                      <tr style={{ background: "#f3f4f6" }}>
                        {previewData.uploadedColumns.map(col => (
                          <th key={col} style={{ padding: "8px", border: "1px solid #ddd" }}>{col}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {previewData.previewRows.map((row, idx) => (
                        <tr key={idx}>
                          {previewData.uploadedColumns.map(col => (
                            <td key={col} style={{ padding: "8px", border: "1px solid #ddd" }}>{row[col]}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === "org" && <OrgManager />}
        {activeTab === "entities" && <EntityManager />}
        {activeTab === "payments" && <PaymentTracker role={user.role} />}
        {activeTab === "approvals" && user.role === "Admin" && <ApprovalCenter />}
        {activeTab === "backups" && user.role === "Admin" && <BackupSettings />}

        {activeTab === "logs" && user.role === "Admin" && (
          <div className="card padding" style={{ background: "white", borderRadius: "12px" }}>
            <h3>System Audit Logs</h3>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "13px", marginTop: "15px" }}>
              <thead>
                <tr style={{ background: "#f3f4f6" }}>
                  <th style={{ padding: "8px", textAlign: "left" }}>Timestamp</th>
                  <th style={{ padding: "8px", textAlign: "left" }}>User Email</th>
                  <th style={{ padding: "8px", textAlign: "left" }}>Role</th>
                  <th style={{ padding: "8px", textAlign: "left" }}>Action</th>
                  <th style={{ padding: "8px", textAlign: "left" }}>Description</th>
                </tr>
              </thead>
              <tbody>
                {activityLogs.map((l) => (
                  <tr key={l.id} style={{ borderBottom: "1px solid #eee" }}>
                    <td style={{ padding: "8px" }}>{new Date(l.timestamp).toLocaleString()}</td>
                    <td style={{ padding: "8px", fontWeight: "600" }}>{l.userEmail}</td>
                    <td style={{ padding: "8px" }}>{l.userRole}</td>
                    <td style={{ padding: "8px" }}>
                      <span style={{
                        padding: "2px 6px", borderRadius: "4px", fontSize: "11px", fontWeight: "bold",
                        background: "#e0f2fe", color: "#0369a1"
                      }}>{l.action}</span>
                    </td>
                    <td style={{ padding: "8px" }}>{l.description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>

      {/* Floating AI Chat Assistant */}
      <AIChatAssistant />

      {/* Email Sharing Modal */}
      <EmailShareModal
        isOpen={isEmailModalOpen}
        onClose={() => setIsEmailModalOpen(false)}
        filters={{
          reportId: selectedReportId,
          ...selectedFilters,
          dateRange,
          profitRange,
          billingRange,
          searchText
        }}
      />

      {/* Template Modal */}
      {isTemplateModalOpen && (
        <div style={{
          position: "fixed", top: 0, left: 0, width: "100%", height: "100%",
          background: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center",
          alignItems: "center", zIndex: 1000
        }}>
          <div style={{ background: "white", padding: "20px", borderRadius: "8px", width: "350px" }}>
            <h4 style={{ marginTop: 0 }}>Save Filter Template</h4>
            <input
              type="text"
              placeholder="Template Name (e.g. Chennai Sea Freight)"
              value={templateNameInput}
              onChange={(e) => setTemplateNameInput(e.target.value)}
              style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ccc", marginBottom: "15px" }}
            />
            <div style={{ display: "flex", justifyContent: "flex-end", gap: "8px" }}>
              <button onClick={() => setIsTemplateModalOpen(false)} style={{ background: "#ccc" }}>Cancel</button>
              <button onClick={handleSaveTemplate}>Save Template</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
