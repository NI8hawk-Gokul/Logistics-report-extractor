import React, { useState, useEffect } from "react";
import api from "../services/api";

function OrgManager() {
  const [branches, setBranches] = useState([]);
  const [depts, setDepts] = useState([]);
  
  // Branch inputs
  const [bName, setBName] = useState("");
  const [bCode, setBCode] = useState("");
  const [bAddress, setBAddress] = useState("");

  // Dept inputs
  const [dName, setDName] = useState("");
  const [dCode, setDCode] = useState("");
  const [dManager, setDManager] = useState("");

  const fetchData = async () => {
    try {
      const bRes = await api.get("/branches");
      setBranches(bRes.data);
      const dRes = await api.get("/departments");
      setDepts(dRes.data);
    } catch (error) {
      console.error("Failed to load organization settings", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddBranch = async (e) => {
    e.preventDefault();
    if (!bName || !bCode) return;
    try {
      const response = await api.post("/branches", { name: bName, code: bCode, address: bAddress });
      setBranches([...branches, response.data]);
      setBName(""); setBCode(""); setBAddress("");
      alert("Branch added successfully!");
    } catch (error) {
      alert("Failed to add branch: " + error.response?.data?.detail || error.message);
    }
  };

  const handleAddDept = async (e) => {
    e.preventDefault();
    if (!dName || !dCode) return;
    try {
      const response = await api.post("/departments", { name: dName, code: dCode, manager: dManager });
      setDepts([...depts, response.data]);
      setDName(""); setDCode(""); setDManager("");
      alert("Department added successfully!");
    } catch (error) {
      alert("Failed to add department: " + error.response?.data?.detail || error.message);
    }
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
      {/* Branches management */}
      <div className="card padding" style={{ background: "white", borderRadius: "12px", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }}>
        <h3>Company Branches</h3>
        
        <form onSubmit={handleAddBranch} style={{ display: "flex", flexDirection: "column", gap: "8px", marginBottom: "20px", borderBottom: "1px solid #eee", paddingBottom: "15px" }}>
          <h4>Add New Branch</h4>
          <input type="text" placeholder="Branch Name" value={bName} onChange={(e) => setBName(e.target.value)} required style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <input type="text" placeholder="Branch Code" value={bCode} onChange={(e) => setBCode(e.target.value)} required style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <input type="text" placeholder="Address" value={bAddress} onChange={(e) => setBAddress(e.target.value)} style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <button type="submit" style={{ margin: "5px 0" }}>Add Branch</button>
        </form>

        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "14px" }}>
          <thead>
            <tr style={{ background: "#f3f4f6" }}>
              <th style={{ padding: "8px", textAlign: "left" }}>Code</th>
              <th style={{ padding: "8px", textAlign: "left" }}>Branch Name</th>
              <th style={{ padding: "8px", textAlign: "left" }}>Address</th>
            </tr>
          </thead>
          <tbody>
            {branches.map((b) => (
              <tr key={b.id} style={{ borderBottom: "1px solid #eee" }}>
                <td style={{ padding: "8px" }}>{b.code}</td>
                <td style={{ padding: "8px", fontWeight: "600" }}>{b.name}</td>
                <td style={{ padding: "8px" }}>{b.address || "N/A"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Departments management */}
      <div className="card padding" style={{ background: "white", borderRadius: "12px", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }}>
        <h3>Business Departments</h3>
        
        <form onSubmit={handleAddDept} style={{ display: "flex", flexDirection: "column", gap: "8px", marginBottom: "20px", borderBottom: "1px solid #eee", paddingBottom: "15px" }}>
          <h4>Add New Department</h4>
          <input type="text" placeholder="Dept Name" value={dName} onChange={(e) => setDName(e.target.value)} required style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <input type="text" placeholder="Dept Code" value={dCode} onChange={(e) => setDCode(e.target.value)} required style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <input type="text" placeholder="Manager Email" value={dManager} onChange={(e) => setDManager(e.target.value)} style={{ padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }} />
          <button type="submit" style={{ margin: "5px 0" }}>Add Department</button>
        </form>

        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "14px" }}>
          <thead>
            <tr style={{ background: "#f3f4f6" }}>
              <th style={{ padding: "8px", textAlign: "left" }}>Code</th>
              <th style={{ padding: "8px", textAlign: "left" }}>Dept Name</th>
              <th style={{ padding: "8px", textAlign: "left" }}>Manager</th>
            </tr>
          </thead>
          <tbody>
            {depts.map((d) => (
              <tr key={d.id} style={{ borderBottom: "1px solid #eee" }}>
                <td style={{ padding: "8px" }}>{d.code}</td>
                <td style={{ padding: "8px", fontWeight: "600" }}>{d.name}</td>
                <td style={{ padding: "8px" }}>{d.manager || "N/A"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default OrgManager;
