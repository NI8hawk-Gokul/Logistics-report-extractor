import React from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from "recharts";

const COLORS = ["#4f46e5", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"];

function AnalyticsDashboard({ data, role }) {
  const isStaff = role === "Staff";

  if (!data) return <div className="card padding">No analytics data available.</div>;

  return (
    <div className="analytics-dashboard" style={{ marginBottom: "32px" }}>
      <h2 style={{ marginBottom: "20px" }}>Operational Analytics</h2>
      
      <div className="charts-grid">
        {/* Job Status Chart (Visible to all) */}
        <div className="card padding">
          <h3 style={{ marginBottom: "16px" }}>Job Status Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={data.jobStatus || []}
                dataKey="count"
                nameKey="status"
                cx="50%"
                cy="50%"
                outerRadius={80}
                label={(entry) => `${entry.status}: ${entry.count}`}
              >
                {(data.jobStatus || []).map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: "8px", border: "1px solid #e2e8f0", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {!isStaff && (
          <>
            {/* Profit by Agent */}
            <div className="card padding">
              <h3 style={{ marginBottom: "16px" }}>Agent Profitability</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={data.profitByAgent || []}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="agentName" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} />
                  <Tooltip formatter={(value) => `₹${value.toLocaleString()}`} contentStyle={{ borderRadius: "8px", border: "1px solid #e2e8f0", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }} />
                  <Legend />
                  <Bar dataKey="totalProfit" fill="#4f46e5" radius={[4, 4, 0, 0]} name="Total Profit" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Billing by Client */}
            <div className="card padding">
              <h3 style={{ marginBottom: "16px" }}>Client Invoicing Summary</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={data.billingByClient || []}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="clientName" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} />
                  <Tooltip formatter={(value) => `₹${value.toLocaleString()}`} contentStyle={{ borderRadius: "8px", border: "1px solid #e2e8f0", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }} />
                  <Legend />
                  <Bar dataKey="totalBilling" fill="#10b981" radius={[4, 4, 0, 0]} name="Total Invoiced" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Monthly Profit Trend */}
            <div className="card padding">
              <h3 style={{ marginBottom: "16px" }}>Monthly Operating Profit Trend</h3>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={data.monthlyProfit || []}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} />
                  <Tooltip formatter={(value) => `₹${value.toLocaleString()}`} contentStyle={{ borderRadius: "8px", border: "1px solid #e2e8f0", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }} />
                  <Legend />
                  <Line type="monotone" dataKey="profit" stroke="#4f46e5" strokeWidth={2.5} name="Net Profit" activeDot={{ r: 8 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Expense vs Profit comparison */}
            <div className="card padding">
              <h3 style={{ marginBottom: "16px" }}>Profit vs Expense Comparison</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={data.expenseVsProfit || []}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} />
                  <Tooltip formatter={(value) => `₹${value.toLocaleString()}`} contentStyle={{ borderRadius: "8px", border: "1px solid #e2e8f0", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }} />
                  <Legend />
                  <Bar dataKey="value" fill="#8b5cf6" radius={[4, 4, 0, 0]} name="Amount">
                    {(data.expenseVsProfit || []).map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={index === 0 ? "#ef4444" : "#10b981"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default AnalyticsDashboard;
