import React, { useState, useEffect } from "react";
import api from "../services/api";

function BackupSettings() {
  const [backups, setBackups] = useState([]);
  const [creating, setCreating] = useState(false);

  const fetchBackups = async () => {
    try {
      const response = await api.get("/backups");
      setBackups(response.data);
    } catch (error) {
      console.error("Failed to load backups list", error);
    }
  };

  useEffect(() => {
    fetchBackups();
  }, []);

  const handleCreateBackup = async () => {
    setCreating(true);
    try {
      const response = await api.post("/backups/create");
      alert("Database snapshot created: " + response.data.backupId);
      fetchBackups();
    } catch (error) {
      alert("Failed to create snapshot: " + error.response?.data?.detail || error.message);
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="card padding" style={{ background: "white", borderRadius: "12px", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "15px" }}>
        <h3 style={{ margin: 0 }}>Database Backups & Configuration Settings</h3>
        <button onClick={handleCreateBackup} disabled={creating} style={{ margin: 0 }}>
          {creating ? "Creating Backup..." : "Create Backup Snapshot"}
        </button>
      </div>

      <p>System backups serialize current MongoDB logs, organization configurations, and user archives.</p>

      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "14px", marginTop: "15px" }}>
        <thead>
          <tr style={{ background: "#f3f4f6" }}>
            <th style={{ padding: "10px", textAlign: "left" }}>Backup ID</th>
            <th style={{ padding: "10px", textAlign: "left" }}>Created By</th>
            <th style={{ padding: "10px", textAlign: "left" }}>Timestamp</th>
          </tr>
        </thead>
        <tbody>
          {backups.map((b) => (
            <tr key={b.id} style={{ borderBottom: "1px solid #eee" }}>
              <td style={{ padding: "10px", fontWeight: "600" }}>{b.backupId}</td>
              <td style={{ padding: "10px" }}>{b.createdBy}</td>
              <td style={{ padding: "10px" }}>{new Date(b.createdAt).toLocaleString()}</td>
            </tr>
          ))}
          {backups.length === 0 && (
            <tr>
              <td colSpan={3} style={{ padding: "15px", textAlign: "center", color: "#6b7280" }}>
                No database backups created yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default BackupSettings;
