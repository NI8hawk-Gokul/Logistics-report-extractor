import React, { useState, useEffect } from "react";
import api from "../services/api";

function ApprovalCenter() {
  const [requests, setRequests] = useState([]);

  const fetchRequests = async () => {
    try {
      const response = await api.get("/approvals");
      setRequests(response.data);
    } catch (error) {
      console.error("Failed to load approvals queue", error);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  const handleApprove = async (approvalId) => {
    try {
      const response = await api.patch(`/approvals/${approvalId}/approve`);
      alert(response.data.message || "Action approved successfully!");
      fetchRequests();
    } catch (error) {
      alert("Failed to authorize request: " + error.response?.data?.detail || error.message);
    }
  };

  return (
    <div className="card padding" style={{ background: "white", borderRadius: "12px", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }}>
      <h3>Logistics Operations Authorization Center</h3>
      <p>The following high-value or sensitive operations require administrator authorization:</p>

      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "14px", marginTop: "15px" }}>
        <thead>
          <tr style={{ background: "#f3f4f6" }}>
            <th style={{ padding: "10px", textAlign: "left" }}>Action Type</th>
            <th style={{ padding: "10px", textAlign: "left" }}>Requested By</th>
            <th style={{ padding: "10px", textAlign: "left" }}>Amount / Value</th>
            <th style={{ padding: "10px", textAlign: "left" }}>Status</th>
            <th style={{ padding: "10px", textAlign: "center" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {requests.map((r) => (
            <tr key={r.id} style={{ borderBottom: "1px solid #eee" }}>
              <td style={{ padding: "10px", fontWeight: "600" }}>{r.targetType}</td>
              <td style={{ padding: "10px" }}>{r.requestedBy}</td>
              <td style={{ padding: "10px" }}>₹{(r.amount || 0).toLocaleString()}</td>
              <td style={{ padding: "10px" }}>
                <span style={{
                  padding: "4px 8px", borderRadius: "12px", fontSize: "12px", fontWeight: "bold",
                  background: r.status === "Approved" ? "#d1fae5" : "#fef3c7",
                  color: r.status === "Approved" ? "#065f46" : "#d97706"
                }}>
                  {r.status}
                </span>
              </td>
              <td style={{ padding: "10px", textAlign: "center" }}>
                {r.status === "Pending" && (
                  <button onClick={() => handleApprove(r.approvalId)} style={{ padding: "6px 12px", fontSize: "12px", margin: 0 }}>
                    Approve
                  </button>
                )}
              </td>
            </tr>
          ))}
          {requests.length === 0 && (
            <tr>
              <td colSpan={5} style={{ padding: "15px", textAlign: "center", color: "#6b7280" }}>
                No pending authorization requests in queue.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default ApprovalCenter;
