import React, { useState, useEffect, useRef } from "react";
import api from "../services/api";

function AIChatAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const chatEndRef = useRef(null);

  const fetchHistory = async () => {
    try {
      const response = await api.get("/ai-chat/history");
      const history = response.data.map(item => [
        { text: item.query, sender: "user" },
        { text: item.reply, sender: "ai" }
      ]).flat().reverse();
      setMessages(history);
    } catch (error) {
      console.error("Failed to load chat history", error);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchHistory();
    }
  }, [isOpen]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    const userMessage = { text: query, sender: "user" };
    setMessages(prev => [...prev, userMessage]);
    setQuery("");
    setLoading(true);

    try {
      const response = await api.post("/ai-chat", { query: userMessage.text });
      setMessages(prev => [...prev, { text: response.data.reply, sender: "ai" }]);
    } catch (error) {
      setMessages(prev => [...prev, { text: "Failed to fetch response from AI assistant.", sender: "ai" }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ position: "fixed", bottom: "20px", right: "20px", zIndex: 9999 }}>
      {/* Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        style={{
          width: "60px", height: "60px", borderRadius: "50%", background: "#1e3a8a",
          color: "white", fontSize: "24px", border: "none", boxShadow: "0 4px 16px rgba(0,0,0,0.2)",
          cursor: "pointer", display: "flex", justifyContent: "center", alignItems: "center", margin: 0
        }}
      >
        💬
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div style={{
          position: "absolute", bottom: "75px", right: 0, width: "350px", height: "450px",
          background: "white", borderRadius: "12px", boxShadow: "0 4px 20px rgba(0,0,0,0.15)",
          display: "flex", flexDirection: "column", overflow: "hidden", border: "1px solid #e5e7eb"
        }}>
          {/* Header */}
          <div style={{ background: "#1e3a8a", color: "white", padding: "12px 15px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h4 style={{ margin: 0 }}>AI Operations Assistant</h4>
            <button onClick={() => setIsOpen(false)} style={{ background: "transparent", color: "white", padding: 0, margin: 0, fontSize: "16px" }}>×</button>
          </div>

          {/* Messages List */}
          <div style={{ flex: 1, padding: "15px", overflowY: "auto", display: "flex", flexDirection: "column", gap: "10px", background: "#f9fafb" }}>
            {messages.map((m, idx) => (
              <div
                key={idx}
                style={{
                  alignSelf: m.sender === "user" ? "flex-end" : "flex-start",
                  background: m.sender === "user" ? "#3b82f6" : "white",
                  color: m.sender === "user" ? "white" : "#1f2937",
                  padding: "8px 12px",
                  borderRadius: "12px",
                  maxWidth: "80%",
                  fontSize: "13px",
                  boxShadow: m.sender === "user" ? "none" : "0 2px 6px rgba(0,0,0,0.05)",
                  border: m.sender === "user" ? "none" : "1px solid #e5e7eb",
                  whiteSpace: "pre-line"
                }}
              >
                {m.text}
              </div>
            ))}
            {loading && (
              <div style={{ alignSelf: "flex-start", background: "#eee", padding: "8px 12px", borderRadius: "12px", fontSize: "12px" }}>
                AI is thinking...
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input Form */}
          <form onSubmit={handleSend} style={{ borderTop: "1px solid #e5e7eb", padding: "10px", display: "flex", gap: "8px", background: "white" }}>
            <input
              type="text"
              placeholder="Ask about profits, billing, agent jobs..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              style={{ flex: 1, padding: "8px 10px", borderRadius: "6px", border: "1px solid #ccc", fontSize: "13px", outline: "none" }}
            />
            <button type="submit" style={{ margin: 0, padding: "8px 12px" }}>Send</button>
          </form>
        </div>
      )}
    </div>
  );
}

export default AIChatAssistant;
