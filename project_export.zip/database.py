import os
import motor.motor_asyncio
from dotenv import load_dotenv

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DATABASE_NAME = os.getenv("DATABASE_NAME", "logistics_report_db")

client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URI)
db = client[DATABASE_NAME]

# Collections
users_collection = db["users"]
reports_collection = db["reports"]
report_versions_collection = db["report_versions"]
report_access_collection = db["report_access"]
report_templates_collection = db["report_templates"]
scheduled_reports_collection = db["scheduled_reports"]
activity_logs_collection = db["activity_logs"]
branches_collection = db["branches"]
departments_collection = db["departments"]
clients_collection = db["clients"]
agents_collection = db["agents"]
jobs_collection = db["jobs"]
payments_collection = db["payments"]
login_history_collection = db["login_history"]
login_otps_collection = db["login_otps"]
documents_collection = db["documents"]
approval_requests_collection = db["approval_requests"]
backups_collection = db["backups"]
system_settings_collection = db["system_settings"]
notifications_collection = db["notifications"]
data_validation_logs_collection = db["data_validation_logs"]

def get_database():
    return db
