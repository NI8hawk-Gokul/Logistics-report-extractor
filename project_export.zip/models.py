from pydantic import BaseModel, EmailStr
from typing import List, Dict, Any, Optional

class LoginRequest(BaseModel):
    email: str
    password: str

class LoginOTPRequest(BaseModel):
    email: str
    otp: str

class FilterRequest(BaseModel):
    agentName: Optional[List[str]] = []
    clientName: Optional[List[str]] = []
    jobType: Optional[List[str]] = []
    status: Optional[List[str]] = []
    branch: Optional[List[str]] = []
    department: Optional[List[str]] = []
    dateRange: Optional[Dict[str, str]] = {"fromDate": "", "toDate": ""}
    profitRange: Optional[Dict[str, str]] = {"minProfit": "", "maxProfit": ""}
    billingRange: Optional[Dict[str, str]] = {"minBilling": "", "maxBilling": ""}
    searchText: Optional[str] = ""
    reportId: Optional[str] = ""

class ColumnMappingRequest(BaseModel):
    reportId: str
    mapping: Dict[str, str]

class SaveTemplateRequest(BaseModel):
    templateName: str
    filters: Dict[str, Any]

class ScheduledReportRequest(BaseModel):
    scheduleName: str
    templateId: str
    receiverEmail: str
    emailSubject: str
    emailMessage: str
    attachmentType: str
    frequency: str
    deliveryTime: str
    dayOfWeek: Optional[str] = None
    dayOfMonth: Optional[int] = None

class ReportAccessRequest(BaseModel):
    reportId: str
    assignedToType: str  # 'user' or 'role'
    assignedTo: str      # email or role name
    permissions: Dict[str, bool]

class ReportVersionRequest(BaseModel):
    reportName: str
    reportType: str
    period: str
    description: Optional[str] = ""

class BranchRequest(BaseModel):
    name: str
    code: str
    address: Optional[str] = ""

class DepartmentRequest(BaseModel):
    name: str
    code: str
    manager: Optional[str] = ""

class ClientRequest(BaseModel):
    name: str
    email: str
    phone: str
    address: Optional[str] = ""

class AgentRequest(BaseModel):
    name: str
    email: str
    phone: str
    branch: str

class JobRequest(BaseModel):
    jobNo: str
    clientName: str
    agentName: str
    jobType: str
    status: str
    billingAmount: float
    expense: float
    profit: float
    date: str
    branch: str
    department: str

class AIChatRequest(BaseModel):
    query: str

class ShareReportEmailRequest(BaseModel):
    toEmail: str
    subject: str
    message: str
    attachmentType: str
    filters: Dict[str, Any]
